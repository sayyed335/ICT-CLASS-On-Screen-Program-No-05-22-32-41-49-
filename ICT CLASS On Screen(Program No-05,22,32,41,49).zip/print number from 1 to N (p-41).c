#include<stdio.h>
void main()
{
    int n,count=1;
    printf("enter the last number where the count end :");
    scanf("%d",&n);
    start:
        if(count>n) ///if the count is greater than user given number end program
            goto end;
        printf(" %d ",count); ///if the count is less than user given number print the count value
        ++count; ///also increase the count variable
        goto start ; ///and process this until the if statement false
        end:
            putchar('\n');
}

