#include<stdio.h> ///header file
#define PI 3.14 ///fixed value define
void main()
{
    float area,radius; ///PI=3.14 also declare here>>> float PI=3.14;
    printf("enter radius:");
    scanf("%f",&radius);
    area=PI*radius*radius;///calculation the area of circle
    printf("the area of circle is %.2f",area);
}
