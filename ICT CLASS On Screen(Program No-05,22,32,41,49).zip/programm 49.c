#include<stdio.h>
void main()
{
    int i,p=0,n=0,number[5];
    printf("type five numbers ");
    for (i=0;i<5;i++) ///for loop for user input 0 to 4 location "number[0] to number[4]"
        scanf("%d",&number[i]);
    ///p=0;
    ///n=0;
    for(i=0;i<5;i++)///for loop for execute user input  "number[0] to number[4]"
        if(number[i]>=0) ///for checking which number is positive
        p=p+1; ///put the positive value
    else
        n=n+1; ///put the negative value
    printf("total positive number= %d \n",p);///print the positive value
    printf("total negative number= %d \n",n);///print the negative value

}
