#include<stdio.h>
void main ()
{
    int i,n,prod;
    printf("enter a number: ");///which number you want to multiply
    scanf("%d",&n);
    for(i=1;i<=10;i++) ///for multiply 1 to 10 with given number
    {
        prod=n*i ; ///store in the prod variable , the result of n*i
        printf("%d*%d=%d\n",n,i,prod);///print the pattern of the multiplication
    }
}
