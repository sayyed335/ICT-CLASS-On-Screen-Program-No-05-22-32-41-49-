#include<stdio.h>
void main()
{
    char ch;
    printf("enter A,a,B,b,1,2:");
    ch=getche(); ///character input
    switch (ch) ///check the character through switch case statement
    {
   case'a':
   case'A':
   case'B':
   case'b':
   case'1':
   case'2':
printf("\n you have written a,A,B,b,1,2");///if user input legal input "A,a,B,b,1,2" then print this
break;
default:
printf("\n you have not written a,A B,b,1,2");///another input print this
    }

}
